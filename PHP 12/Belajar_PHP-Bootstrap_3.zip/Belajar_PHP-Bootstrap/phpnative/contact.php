    <!-- start form -->
    <div class="container">
    <h2>Form kontak</h2>
    <form action="" class="contact-form">
        <div>
            <label for="nama">Nama Lengkap</label><br>
            <input type="text" placeholder="Nama Lengkap" size="50" name="nama" id="nama">
        </div>
         
        <div>
            <label for="kota">Kota</label><br>
            <input type="text" placeholder="Kota" size="50" name="kota" id="kota">
        </div>

        <div>   
            <label for="email">E-mail</label><br>
            <input type="email" placeholder="E-mail" size="50" name="email" id="email">
        </div>

        <div>
            <label for="pesan">Pesan</label>
            <br>
            <textarea name="pesan" id="pesan" cols="50" rows="10" placeholder="Tulis pesan disini"></textarea>
        </div>

        <div>
            <input type="submit" name="kirim" id="kirim" value="Kirim">
        </div>
    </form>
    </div>
    <!-- end form -->


    <!-- start menu sekunder -->
    <div class="container-full menu-sekunder">
        <div class="container">
        <!-- start jang4r -->
            <div class="menu-sekunder-one" id="contact">
                <p>Hubungi :</p>
                <p>Email : <a href="#" title="email">example@gmail.com</a></p>
                <p>WA : <a href="#" title="no">+62-123-456-789</a></p>
            </div>
        </div>
    </div>
        <!-- end jang4r -->