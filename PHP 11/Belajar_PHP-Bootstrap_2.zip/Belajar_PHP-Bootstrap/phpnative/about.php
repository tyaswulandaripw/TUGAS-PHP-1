<div class="about">
    <h1 class="mt-4">Tentang</h1>
    <p>Saya adalah mahasiswa Politeknik Negeri Lhokseumawe dibidang Teknologi Rekayasa Komputer Jaringan.</p>

<h1 class="mt-4">Sosial Media</h1>
<ul>
    <li><a href="https://github.com/RIZKIINC">Github</a></li>
    <li><a href="https://www.facebook.com/rizkiinc/">Facebook</a></li>
        <li><a href="https://www.instagram.com/rizkiilhami27/">Instagram</a></li>
    </ul>
</div>
<div>
    <img src="https://dialeksis.com/images/web/2022/01/POLITEKNIK-NEGERI-LHOKSEUMAWE.webp" alt="" id="poltek">
</div>

<style>
    .about {
        background: #00000010;
        padding-left: 20px;
        padding-bottom: 20px;
        padding-top: 10px;
        margin-top: 30px;
        border-radius: 15px 15px 0px 0px;
    }

    .about ul li a, .about ul li {
        margin-left: -12px;
        list-style-type: none;
        text-decoration: none;
        color: black;
    }

    .about ul li a:hover {
        text-decoration: underline;
    }

    #poltek {
        width: 100%;
        border-radius: 0px 0px 15px 15px;

    }
</style>